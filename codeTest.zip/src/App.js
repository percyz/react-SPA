import React, { Component } from 'react';
import Header from './components/header.jsx';
import Content from './components/content.jsx';
import './App.css';

export default class App extends Component {
  render() {
    return (
      <div className="App">

        {/* The header of the page, including navigation */}
        <Header />
        
        {/* The body of page */}
        <Content /> 

      </div>
    );
  }
}

