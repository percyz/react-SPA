import React, { Component } from 'react';
import '../App.css'; 

export default class SignUp extends Component {
  render() {
    return (
        <div>
          <h3>Please sign up</h3>
        </div>
    );
  }
}
